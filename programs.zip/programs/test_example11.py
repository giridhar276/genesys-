


#pytest -k "slow" test_example11.py

import pytest

@pytest.mark.slow
def test_slow_operation():
    # test logic here
    pass

