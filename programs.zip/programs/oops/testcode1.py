import os
class MenuOperation:
    def displayFiles(self,getdir):
        self.files = os.listdir(getdir)
        for file in self.files:
            print(file)
if __name__ == "__main__":
    obj1= MenuOperation()
    print("---------- MENU-------------")
    print("1.display all the files")
    print("2.delete a file :")
    print("3.diplay login")
    print("exit")
    choice = int(input("Enter your choice:"))
    if choice == 1:
        obj1.displayFiles(os.getcwd())
        
        