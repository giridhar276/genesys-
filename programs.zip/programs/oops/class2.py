


class Employee:
    def __init__(self,name,age):
        self.name = name
        self.age = age
    def displayEmployee(self):
        print("Employee name :",self.name)
        print("EMployee age  :", self.age)
        
# this condition will be always True if code is executed directly
if __name__ == "__main__":
    emp1 = Employee('Ram',26)
    emp1.displayEmployee()
    
    emp2 = Employee('Rita',23)
    emp2.displayEmployee()