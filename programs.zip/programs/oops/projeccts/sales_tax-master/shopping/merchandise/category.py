# from the order list we can identify few generalized category
# it is formed in static dictionary, where key is category and value is
# list of tokens

categories = {
    'book': ['book'],
    'music': ['music'],
    'food': ['chocolate', 'chocolates'],
    'accessory': ['perfume'],
    'pharmacy': ['pills']
}
