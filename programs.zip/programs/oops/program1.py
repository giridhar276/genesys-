




def method1():
    print('this is method1')
    
def method2():
    print('this is method2')
    
def method3():
    print('this is method3')
   

# if this program is executed directly .. the below condition becomes True
# if this program is imported to some other program.. the below condition becomes false
if __name__ == "__main__":
    method1()
    method2()
    method3()