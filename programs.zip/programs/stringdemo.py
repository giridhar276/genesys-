name = 'python programming'
print(name.capitalize())
print(name.endswith('g'))
print(name.startswith("p"))
print(name.startswith("m"))
print(name.count("p"))
print(name.replace('python','java'))
print(name.isupper())
print(name.isalnum())
print(name)
aname = ' python  '
print(len(aname))
print(len(aname.strip( )))
print(len(aname.lstrip( )))
print(len(aname.rstrip( )))

bname = "I love {} and {}"
print(bname.format('unix','java'))
print(bname.format("perl","python"))
