
#pip install Flask pytest-flask


from flask import Flask

app = Flask(__name__)

@app.route('/')
def home():
    return 'Hello, World!'

def test_home_endpoint(client):
    response = client.get('/')
    assert response.status_code == 200
    #assert response.data == b'Hello, World!'

