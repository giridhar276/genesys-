import pymysql

try:
    #step1
    conn = pymysql.connect(host='127.0.0.1',port=3306,user='root',password='yourpassword')
    if conn:
        cursor = conn.cursor()
        #step2
        query = "select * from genesys.supermarket"
        #step3
        cursor.execute(query)
        #step4
        for record in cursor.fetchall():
            print(record)
    #step5
    conn.close()
except Exception as err:
    print(err)