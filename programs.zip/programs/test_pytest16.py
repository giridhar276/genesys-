


from unittest.mock import Mock

def test_using_mock():
    mock_obj = Mock(return_value=42)
    result = mock_obj()
    assert result == 40