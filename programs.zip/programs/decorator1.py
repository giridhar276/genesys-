

def first(msg):
    print(msg)


first("Hello")



second = first
second("Hello")


print(id(second))
print(id(first))