import pymysql
import csv
try:
    #step1
    count = 0
    conn = pymysql.connect(host='127.0.0.1',port=3306,user='root',password='giri@123')
    if conn:
        cursor = conn.cursor()
        #step2
        with open("sales.csv","r") as fobj:
            reader = csv.reader(fobj)
            for line in reader:
                product = line[1]
                payment = line[3]
                name = line[4]
                query = "insert into genesys.supermarket values('{}','{}','{}')".format(product,payment,name)
                #step3
                cursor.execute(query)
                count = count + 1
        #step4
        print(count,"records inserted")
    #step5
    conn.commit()
    conn.close()
except Exception as err:
    print(err)