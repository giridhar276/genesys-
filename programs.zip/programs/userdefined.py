#fixed args
def display(a,b):
    print(a,b)
display(10,20)
#default arguments
def display(a= 0,b=0):
    print(a,b)
display()
display(10)
display(10,20)
#keyword args
def display(c,a,b):
    print(a,b,c)
display(a=10,b=20,c=30)

# variable length  arguments
def display(*args):
    for val in args:
        print(val)
display(10,20,30,40,"unix")

def displayinfo(**kwargs):
    for k,v in kwargs.items():
        print(k,v)
displayinfo(chap1=10,chap2=20)