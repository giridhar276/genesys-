name = 'python programming'
getcount = name.count('gram')
if getcount > 0:
    print("substring exists")

if name.find('gram') != -1:
    print("substring exists")

if 'gram' in name:
    print("substring exists")

alist = [10,20,30,40]
if 10 in alist:
    print("exists")

book = {"chap1":10,"chap2":20}
if 'chap1' in book:
    print("exists")
else:
    print("doesnt exist")


