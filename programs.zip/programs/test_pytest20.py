

import pytest
# The fixture function (setup_module) uses the yield statement, 
#indicating the point where the setup code executes before the test and the teardown code executes after the test.

@pytest.fixture
def setup_and_teardown():
    print("\n=== Setup ===")
    yield
    print("\n=== Teardown ===")

def test_using_fixture(setup_and_teardown):
    print("Test logic here")
    assert False