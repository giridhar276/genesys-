

# used for interacting with OS and running external processes.

import subprocess

#result = subprocess.run(["ls","-l"] ,stdout=subprocess.PIPE,shell=True)
result = subprocess.run(["dir"] ,stdout=subprocess.PIPE,shell=True)
print(result.stdout.decode('utf-8'))

#shell=True  is used to run the command in shell.


