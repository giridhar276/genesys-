import pymysql

try:
    #step1
    conn = pymysql.connect(host='127.0.0.1',port=3306,user='root',password='giri@123')
    if conn:
        cursor = conn.cursor()
        #step2
        query = "insert into genesys.supermarket values('{}','{}','{}')".format('product4','visa','Ram')
        #step3
        cursor.execute(query)
        #step4
        print(cursor.rowcount,"record inserted")
    #step5
    conn.commit()
    conn.close()
except Exception as err:
    print(err)