

import pytest
import requests

@pytest.fixture
def mock_weather_data(mocker):
    url = "https://api.weather.com/current"
    weather_data = {"temperature": 25, "condition": "Sunny"}
    mocker.patch('requests.get', return_value=requests.Response())
    mocker.patch('requests.Response.json', return_value=weather_data)
    return url, weather_data

def test_fetch_weather_data(mock_weather_data):
    url, expected_data = mock_weather_data
    response = requests.get(url)
    assert response.json() == expected_data
