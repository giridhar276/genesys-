# keyword arguments
def display(*args):
    for val in args:
        print(val)
display(10,20,30,40,"unix")


def displayinfo(**kwargs):
    for k,v in kwargs.items():
        print(k,v)

displayinfo(chap1=10,chap2=20)