# tests/test_utils.py
import pytest
from src.utils_module import multiply_numbers

def test_multiply_numbers():
    result = multiply_numbers(2, 3)
    assert result == 6