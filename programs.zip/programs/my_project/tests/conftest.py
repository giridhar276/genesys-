import pytest
from src.main_module import add_numbers

@pytest.fixture
def setup_and_teardown():
    print("\n=== Setup ===")
    yield
    print("\n=== Teardown ===")

@pytest.fixture
def add_fixture():
    return add_numbers