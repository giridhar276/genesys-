# src/main_module.py
def add_numbers(a, b):
    return a + b