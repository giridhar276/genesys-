# src/utils_module.py
def multiply_numbers(a, b):
    return a * b