#pip install pytest-selenium


# test_example.py
import pytest
from selenium import webdriver

@pytest.fixture
def browser():
    driver = webdriver.Chrome()
    yield driver
    driver.quit()

def test_web_app(browser):
    browser.get("https://example.com")
    assert "Example Domain" in browser.title