name = 'python'
for char in name:
    print(char)

alist = [10,20,30]
for val in alist:
    print(val)

book = {"chap1":10 ,"chap2":20}
for key in book:
    print(key)

for key in book.keys():
    print(key)

for value in book.values():
    print(value)

for k,v in book.items():
    print(k,v)

