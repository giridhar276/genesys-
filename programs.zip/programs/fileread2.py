#method2 - usinf fobj.readlines()
with open("supermarket_sales.csv","r") as fobj:
    print(fobj.readlines())
with open("supermarket_sales.csv","r") as fobj:
    for line in fobj.readlines():
        print(line)

#method3 - using fobj.read()----> string
with open("supermarket_sales.csv","r") as fobj:
    print(fobj.read())

#metho4 - usinf csv library
import csv
with open("supermarket_sales.csv","r") as fobj:
    #converting file object to csv object
    data = csv.reader(fobj)
    for line in data:
        print(line)

#method5 - using pandas
import pandas
df = pandas.read_csv("supermarket_sales.csv")
print(df)