
try:
    with open("numbers.txt","w") as fobj:
        for val in range(100,140):
            fobj.write(str(val)  + "\n")
except FileNotFoundError as err:
    print(err)
    print("File not found.. please check")
except TypeError as err:
    print(err)
    print("Invalid operation.. please check")
except (IndexError,KeyError) as err:
    print(err)
    print('Index not found.. please check')
except Exception as err:
    print(err)
    print("Exception found")