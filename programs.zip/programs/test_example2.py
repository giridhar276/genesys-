#Assertion Failures
#Let's intentionally create a failing test:


def test_addition():
    assert 1 + 1 == 3