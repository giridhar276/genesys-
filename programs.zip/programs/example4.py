data = {
"id": "0001",
"type": "donut",
"name": "Cake",
"image":
{
"url": "images/0001.jpg",
"width": 200,
"height": 200
},
"thumbnail":
{
"url": "images/thumbnails/0001.jpg",
"width": 32,
"height": 32
}
}


for k,v in data.items():
    if isinstance(v,str):
        print(k.ljust(20),":",v)
    elif isinstance(v,dict):
        for sk,sv in v.items():
            finalkey = k + "." + sk
            print(finalkey.ljust(20),":",sv)

