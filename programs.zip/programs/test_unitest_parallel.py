alist = [10,20,30]
print(list(map(str,alist)))
