import pymysql
import csv
class Database:
    def __init__(self,host,port,user,password,database):
        self.host = host
        self.port = port
        self.user = user
        self.password = password
        self.database = database
        
    def connectDatabase(self):
        self.conn = pymysql.connect(host=self.host,port=self.port,user=self.user,password=self.password,database=self.database)
        print(self.conn)
    def processData(self):
        count = 0
        self.cursor = self.conn.cursor()
        with open("sales.csv","r") as self.fobj:
            self.reader = csv.reader(self.fobj)
            for line in self.reader:
                product = line[1]
                payment = line[3]
                name = line[4]
                self.query = "insert into genesys.supermarket values('{}','{}','{}')".format(product,payment,name)
                #step3
                self.cursor.execute(self.query)
                count = count + 1
        #step4
        print(count,"records inserted")
    def closeDatabase(self):
        self.conn.commit()
        self.conn.close()

db = Database('127.0.0.1',3306,'root','giri@123','genesys')
db.connectDatabase()
db.processData()
db.closeDatabase()