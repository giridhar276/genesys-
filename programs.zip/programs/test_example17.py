

#Skipping Tests Conditionally
#You can skip a test conditionally using an if statement within the test:

import pytest

def test_skip_conditionally():
    if  1<2:
        pytest.skip("Skipping test because of some condition")
    assert True