
'''
Fixture Example
Fixtures are a way to provide data or set up conditions for tests. 
Here's a simple fixture example:
'''


# test_example.py
import pytest

@pytest.fixture
def sample_data():
    return [1, 2, 3, 4, 5]

def test_list_length(sample_data):
    assert len(sample_data) == 43