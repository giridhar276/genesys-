

import pytest
from selenium import webdriver

@pytest.fixture
def browser():
    driver = webdriver.Chrome()
    yield driver
    driver.quit()

def test_web_app(browser):
    browser.get("https://www.example.com")
    assert "Example Domain" in browser.title