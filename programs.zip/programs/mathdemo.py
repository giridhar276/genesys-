#method1 importing all the methods to your programspace
import math
print(math.tan(3))
print(math.log(1))

#metho2 : importing with alias name
import math as m
print(m.cos(1))
print(m.floor(34.2))

#method3: importing required methods only
from math import floor,cos,tan
print(floor(1))
print(cos(2))
print(tan(1))

#method4: importing all the methods
from math import *
print(floor(1))
print(cos(2))
print(tan(1))


import shutil
shutil.co