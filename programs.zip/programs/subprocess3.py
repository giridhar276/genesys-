

#running a command in background

import subprocess
import time

process = subprocess.Popen(['type','sales.csv'],shell=True)

time.sleep(2)
#wait for subprocess to finish
process.wait()
print("subprocess finished")