


import pytest

@pytest.mark.slow
def test_slow_operation():
    # test logic here
    pass


def test_fastest_operation1():
    # test logic here
    pass


def test_fast_operation():
    # test logic here
    pass
