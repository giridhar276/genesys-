import unittest
import calculator as calculator


class TestsCalculator(unittest.TestCase):
    def test_add_functionality(self):    # testcase1
        result = calculator.calc_add(10, 200)
        self.assertEqual(result, 30)

    def test_add_functionality_two_negative_numbers(self):  #case2
        result = calculator.calc_add(-10, -20)
        self.assertEqual(result, -30)


class TestsCalculator2(unittest.TestCase):
    def test_add_functionality2(self):       # testcase3
        result = calculator.calc_add(10, 20)
        self.assertEqual(result, 30)

    def test_add_functionality_two_negative_numbers2(self):
        result = calculator.calc_add(-10, -20)
        self.assertEqual(result, -30)
