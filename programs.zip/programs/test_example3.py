#@pytest.mark.parametrize decorator to write parameterized tests



# test_example.py
import pytest

@pytest.mark.parametrize("a, b, expected", [(1, 1, 2), (2, 3, 3), (0, 0, 0)])
def test_addition(a, b, expected):
    result = a + b
    assert result == expected