book = {"chap1":10 ,"chap2":20 ,"chap3":30, "chap1":100}
# add new key-value
book['chap4'] = 40
book['chap5'] = 50
# display dictionary
print(book)
# accessing individual values
print(book['chap1'])
print(book.get('chap9')) # If key is not existing..returns None
print(book)
# dipslaying keys
print(book.keys())
#display value
print(book.values())
#display items
print(book.items())

newbook = {"chap7":70,"chap8":80}
book.update(newbook)
print(book)

finalbook = {**book,**newbook}
print(finalbook)



