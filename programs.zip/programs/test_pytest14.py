


#Temporarily Modifying Environment
#You can use the monkeypatch fixture to temporarily modify environment variables:

import os

def test_temporarily_modify_env(monkeypatch):
    monkeypatch.setenv("MY_VARIABLE", "new_value")
    assert os.environ["MY_VARIABLE"] == "new_value"