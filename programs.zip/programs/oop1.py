

class Employee:
    def displayEmployee(self):
        print("employee name :","ram")

#object intialization # object declaration
emp1 = Employee()      
emp1.displayEmployee()


