
'''
Running Tests in a Directory
Pytest can discover and run all tests in a directory:

pytest tests/
'''