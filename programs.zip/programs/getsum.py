


def total():
    return 42


#print(total())