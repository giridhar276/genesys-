#Skipping Tests
#You can skip a test using the @pytest.mark.skip decorator:


import pytest

@pytest.mark.skip(reason="Test not implemented yet")
def test_multiply():
    assert 2 * 3 == 6


def test_add():
    assert 2 + 3 == 5    