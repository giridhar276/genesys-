    

import pytest_mock
from pytest_mock import mocker
import getsum


def test_example(mocker):
    mocker.patch('getsum.total', return_value=42)
    assert getsum.total() == 420

