import requests
import json
url = 'https://api.github.com'
endpoint = "/gists"
url = url + endpoint

username = 'giridhar276'
token  = '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'

print("checking ", url, "using user:", username)

local_file = "db2.py"
with open(local_file) as fh:
    mydata = fh.read()
# payload
files = {
    "description": "rest api - giri testing-1",
    "public": "true",
    "user" : username,
    "files": {
    local_file: {
    "content": mydata
        }
      }
}
r1 = requests.post(url, data=json.dumps(files), auth=(username,token))

data = json.loads(r1.text)
print(data['html_url'])

