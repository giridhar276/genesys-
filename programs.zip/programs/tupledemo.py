



alist= [10,20,30,40]

alist[0] = 100
print(alist)


#tuples are always faster compared to the list
atup = (20,30,40,50)
atup[0] = 100
print(atup)


#list of lists
empdb = [['ram','1-1-2000','M'],['shiv','2-2-2000','M']]


#list of tuples
empdb = [('ram','1-1-2000','M'),('shiv','2-2-2000','M')]