alist = [10,20,5,34,67,12,56,3]
# add single value
alist.append(90)
print('After appending :',alist)
alist.extend([82,57])
print('After extending :',alist)
alist.insert(1,200)
print('After isnerting :',alist)
#list.pop(index)
alist.pop(1)
print('After pop operation:',alist)
alist.pop()
print('After pop operation :',alist)

getcount = alist.count(10)
print(getcount)

alist.sort()
print('after sorting :',alist)
alist.sort(reverse=True)
print('after sorting :',alist)

alist.reverse()
print('After reversing :',alist)