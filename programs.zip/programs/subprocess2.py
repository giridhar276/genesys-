
import subprocess
try:
    # Run a command with arguments to display file contents on Windows
    filename = 'sales.csv'
    result = subprocess.run(['type', filename], stdout=subprocess.PIPE, shell=True)

    # Capture the output and print it
    print(result.stdout.decode('utf-8'))
except subprocess.CalledProcessError as err:
    print(err)    


# program
# type sales.csv