#Basically, a decorator takes in a function, 
#adds some functionality and returns it.
def make_pretty(func):
    def inner():
        print("I got decorated")
        func()
    return inner


def ordinary():
    print("I am ordinary")


#make_pretty() is a decorator
# let's decorate this ordinary functio
pretty = make_pretty(ordinary)
pretty()

#The function ordinary() got decorated and the returned function was given the name pretty.
#We can see that the decorator function added some new functionality to the original function
#The decorator acts as a wrapper. 
