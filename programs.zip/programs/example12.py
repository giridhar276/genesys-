
for val in range(1,11):
  print("192.168.0.{}".format(val))