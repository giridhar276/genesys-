

# test_example.py
import pytest

@pytest.fixture(scope="module")
def setup_module():
    print("\n=== Module Setup ===")
    yield
    print("\n=== Module Teardown ===")

def test_module_fixture(setup_module):
    print("Test using module-level fixture")
    assert False