
#- reading the file line by line using file object
try:
    filename = input("Enter any filename :")
    with open(filename,"r") as fobj:
        for line in fobj:
            print(line.strip())
except FileNotFoundError as err:
    print(err)
    print("File not found.. please check")
except TypeError as err:
    print(err)
    print("Invalid operation.. please check")
except (IndexError,KeyError) as err:
    print(err)
    print('Index not found.. please check')
except Exception as err:
    print(err)
    print("Exception found")

