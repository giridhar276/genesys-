#Chaining Decorators in Python
def star(func):
    def inner(*args, **kwargs):
        print("*" * 30)
        func(*args, **kwargs)
        print("*" * 30)
    return inner

def percent(func):
    def inner(*args, **kwargs):
        print("%" * 30)
        func(*args, **kwargs)
        print("%" * 30)
    return inner

#
@percent
@star
def printer(msg):
    print(msg)

@star
@percent
def printer(*msg,**data):
    print(msg,data)
printer("Hello","python",name='ram',age=29)



