
hosts = ["google","oracle","java"]
#["www.google.com"."www.oracle.com","www.java.com"]
#method1
alist = []
for val in hosts:
    alist.append("www." + val + ".com")

#method2
#map(function,iterable)
def check(x):
    return "www." + x + ".com"
print(list(map(check,hosts)))

#method3
print(list(map(lambda x: "www." + x + ".com",hosts)))

alist = ['1','2','3']
print(list(map(lambda x: int(x),alist)))


hosts = ["google","oracle","java","unix","ruby"]
print(list(filter(lambda x: len(x)==4,hosts)))
