
#You can parameterize fixtures as well:

import pytest

@pytest.fixture(params=[1, 2, 3,4,5,-3])
def data(request):
    return request.param

def test_fixture_param(data):
    assert data > 0