# test_example.py
def test_addition():
    assert 1 + 1 == 2