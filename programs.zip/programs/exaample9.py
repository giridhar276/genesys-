import os
import getpass
import sys
import platform
print(os.getcwd())
print(os.getlogin())
print(getpass.getuser())

#) current process id
print(os.getpid())

#4) current python version
print(sys.version)
print(platform.python_version())


#5) all the libraries available in python
print(sys.modules)

#6) all the environment variables
print(os.environ)


#7) operating system name
print(os.name)

#8) platform name
print(platform.platform())


#9)current date and time
import datetime
print(datetime.datetime.now())


print(os.stat("adult.csv").st_atime)
print(os.stat("adult.csv").st_mtime)
print(os.stat("adult.csv").st_ctime)
print(os.stat("adult.csv").st_size,"bytes")


#11)create empty file with today's timestamp	  ( Eg: 21_Sep_2023.csv )
import time
filename = time.strftime("%d_%b_%Y.csv")
fobj = open(filename,"w")
fobj.close()


#12)CPU percentage
import psutil
print(psutil.cpu_percent())

#13)virtual memory
print(psutil.virtual_memory())

#14)swap memory
print(psutil.swap_memory())

#15)disk partitions
print(psutil.disk_partitions())

#16)disk usage
print(psutil.disk_usage("C:\\"))

#17)display boot time
print(psutil.boot_time())
print(datetime.datetime.fromtimestamp(psutil.boot_time()).strftime("%Y-%m-%d %H:%M:%S"))

print(psutil.users())
print(psutil.pids())
