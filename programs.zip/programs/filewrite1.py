''' traditional way
fw = open("numbers.txt","w")
for val in range(100,140):
    fw.write(str(val)  + "\n")
fw.close()
'''
# context manager - pythoic way
# if the line starts with keyword with ... we call it context manager
# Advantage : file gets closed automatically

with open("numbers.txt","w") as fobj:
    for val in range(100,140):
        fobj.write(str(val)  + "\n")

