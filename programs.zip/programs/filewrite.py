
fobj = open("customers.txt","w")
fobj.write("tcs\n")
fobj.write("cts\n")
fobj.close()



fw = open("numbers.txt","w")
for val in range(100,140):
    fw.write(str(val)  + "\n")
fw.close()