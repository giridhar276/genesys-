

import logging

from openpyxl import Workbook
import pymysql
wb = Workbook()
import time
filename = time.strftime("%d_%b_%Y.xlsx")

'''
DEBUG
INFO
WARNING
ERROR
CRITICAl
'''

logging.basicConfig(filename='db.log', level=logging.DEBUG, format='%(asctime)s - %(levelname)s - %(message)s')
try:
    import os
    #step1
    conn = pymysql.connect(host='127.0.0.1',port=3306,user='root',password='giri@123')
    logging.info("connection established")
    # grab the active worksheet
    ws = wb.active
    if conn:
        cursor = conn.cursor()
        logging.info("cursor created")
        #step2
        query = "select * from genesys.supermarket"
        logging.info(query + "executed")
        #step3
        cursor.execute(query)
        #step4
        for record in cursor.fetchall():
            ws.append(record)
    #step5
    if not os.path.isfile(filename):
        logging.warn("file is already existing")
    wb.save(filename)
    logging.info(filename + "saved")
    conn.close()
except Exception as err:
    print(err)
else:
    logging.shutdown()