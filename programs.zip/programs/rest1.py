import requests
import json
url = "https://api.github.com"

endpoint = "/users"

finalurl = url  + endpoint

conn = requests.get(finalurl,auth=("giridhar276","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"))
# convert json to the dictionary
data = json.loads(conn.text)

for item in data:
    print(item['login'])

