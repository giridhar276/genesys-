import requests
try:
    with open("urls.txt") as fobj:
        for line in fobj:
            url = line.strip()
            print(url)
            response = requests.get(url)
            print("URL        :",url)
            print("statuscode :",response.status_code)
            print("---------------------------")
except Exception as err:
    print(err)