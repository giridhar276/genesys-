


import boto3

def terminate():

    # Specify the AMI ID for the desired Amazon Machine Image (replace 'your_ami_id')
    ami_id = 'ami-02a2af70a66af6dfb'

    # Specify the instance type (e.g., 't2.micro')
    instance_type = 't2.micro'

    # Create an EC2 resource
    aws_mag_con_root=boto3.session.Session(profile_name="user14")
    ec2 = aws_mag_con_root.resource('ec2')

    try:
        instance = ec2.Instance("i-03f0ba39d48083296")
        response = instance.terminate()
        print(f"EC2 instance {instance.id} terminated successfully.")

    except Exception as e:
        print(f"Error: {e}")

if __name__ == "__main__":
    terminate()
