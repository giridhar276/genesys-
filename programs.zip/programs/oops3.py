# constructor is a method which is invoked automatically when the object is created


class Employee:
    def __init__(self,name,age,city):
        #self.name is accessible within the methods
        self.name = name
        self.age = age
        self.city = city
    def displayEmployee(self):
        print("employee name :",self.name)
        print("Age :",self.age)
        print("City :",self.city)

#object intialization # object declaration
emp1 = Employee('ram',28,'hyd')      
emp1.displayEmployee()

emp2 = Employee('rao',30,'bang')  
emp2.displayEmployee()