

pip install pytest-html

pytest --html=report.html