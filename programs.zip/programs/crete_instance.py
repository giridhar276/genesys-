
import boto3

def create_ec2_instance():

    # Specify the AMI ID for the desired Amazon Machine Image (replace 'your_ami_id')
    ami_id = 'ami-02a2af70a66af6dfb'

    # Specify the instance type (e.g., 't2.micro')
    instance_type = 't2.micro'

    # Create an EC2 resource
    aws_mag_con_root=boto3.session.Session(profile_name="user14")
    ec2 = aws_mag_con_root.resource('ec2')

    try:
        # Create a new EC2 instance
        instance = ec2.create_instances(
            ImageId=ami_id,
            InstanceType=instance_type,
            MinCount=1,
            MaxCount=1
        )

        #print(f"EC2 instance {instance.id} created successfully.")

    except Exception as e:
        print(f"Error: {e}")

if __name__ == "__main__":
    create_ec2_instance()
