def display(a,b):
    c = a + b
    return c
total = display(10,20)
print(total)

#functional programming
#lambda function - lambda is the replacement of single liner function
#syntax:  
#functioname = lambda variables:expresion
display = lambda a,b:a + b
total = display(10,20)
print(total)

getsquare = lambda x: x if x>0 else "not possible"
print(getsquare(6))
print(getsquare(0))

max = lambda x,y: x if x>y else y
print(max(10,20))

x = lambda n: n**2 if n%2 ==0 else n**3
print(x(4))

