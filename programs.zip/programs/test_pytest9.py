


#This is a context manager provided by pytest. 
#It checks if the code inside the indented block raises a ZeroDivisionError exception. 
#If it does, the test passes; if not, the test fails.
#The code inside the context manager attempts to perform a division by zero, which should raise a ZeroDivisionError exception.


import pytest

def test_division_by_zero():
    with pytest.raises(ZeroDivisionError):
        result = 1 / 9