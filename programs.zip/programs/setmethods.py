

aset = {10,10,20,30,30,30}
bset = {30,30,40,40,50}

print(aset)
print(bset)

print(aset.add(40))
print(aset)
print(aset.union(bset))
print(aset.intersection(bset))
print(aset.difference(bset))
print(aset.issubset(bset))
print(aset.issuperset(bset))