#keyword args
def display(c,a,b):
    print(a,b,c)

display(a=10,b=20,c=30)


print(10,sep="  ",end=" ")
print(20,30)