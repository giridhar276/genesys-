

class TestBasicFunctionality:
    def test_addition(self):
        result = 1 + 1
        assert result == 2

    def test_subtraction(self):
        result = 3 - 1
        assert result == 20